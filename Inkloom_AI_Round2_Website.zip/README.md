# Inkloom AI — Round 2 Website Prototype

A beginner-friendly Flask website for the CodeAxis Hackathon. It demonstrates a text-only brand-governance workflow using fictional sample rules and rule-based checks.

## Features
- Responsive dashboard and draft submission form
- Rule-based checks for exaggerated claims, terminology, all-caps writing, and repeated punctuation
- Explanations and suggested corrections
- Human reviewer can mark a draft Approved, Needs Changes, or Rejected
- SQLite-backed review history
- Sample brand rules page

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create a virtual environment (optional but recommended):
   - Windows: `py -m venv .venv`
   - Activate: `.venv\\Scripts\\activate`
4. Install packages: `pip install -r requirements.txt`
5. Start the website: `python app.py`
6. Open `http://127.0.0.1:5000` in your browser.

## Demo script
1. On Dashboard, submit: `HEY GUYS!! This is the best ever product — 100% guaranteed to work.`
2. Click Check content.
3. Explain the flags and suggested corrections.
4. Click Request changes or Approve.
5. Open Review history to show the saved record.

## Important limitations
- The checks are simple rules, not a full AI model or reliable fact-checker.
- The prototype uses fictional sample rules and has no login or role-based permissions.
- Do not use confidential real company content.
- Do not claim the website automatically verifies all legal, factual, visual, or accessibility issues.
- For public deployment, turn off Flask debug mode, use secure production hosting, and review privacy/security requirements.
