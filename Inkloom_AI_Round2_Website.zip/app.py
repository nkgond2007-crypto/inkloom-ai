from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from pathlib import Path
from datetime import datetime

app = Flask(__name__)
DB_PATH = Path(__file__).with_name("inkloom.db")

SAMPLE_RULES = [
    ("Tone", "Avoid exaggerated or guaranteed claims such as 'best ever', '100% guaranteed', or 'perfect for everyone'.", "Use clear, honest, helpful language."),
    ("Terminology", "Use 'customers' rather than 'guys' when addressing the audience.", "Replace 'guys' with 'customers' or 'everyone'."),
    ("Claims", "Do not claim a product is 'risk-free' or 'guaranteed to work' without approved evidence.", "Describe the benefit accurately and avoid guarantees."),
    ("Style", "Avoid writing the whole message in ALL CAPS.", "Use sentence case and calm punctuation."),
    ("Accessibility", "Avoid using repeated exclamation marks or excessive punctuation.", "Use one period or exclamation mark where appropriate.")
]

def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            draft TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Needs review',
            issues TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")

def check_text(draft):
    lower = draft.lower()
    issues = []
    checks = [
        (["best ever", "100% guaranteed", "perfect for everyone"], "Tone", "This sounds exaggerated or makes a broad promise.", "Use clear, specific wording that does not promise too much."),
        (["guys"], "Terminology", "The sample guideline prefers inclusive audience terminology.", "Replace “guys” with “customers” or “everyone”."),
        (["risk-free", "guaranteed to work"], "Claims", "This is a strong claim that may need approved evidence.", "Describe the benefit accurately and remove the guarantee unless it is approved."),
        ([], "Style", "The draft appears to use all-caps text.", "Use normal sentence case.")
    ]
    for phrases, category, reason, suggestion in checks:
        found = any(p in lower for p in phrases) if phrases else (len(draft) >= 5 and draft.upper() == draft and any(c.isalpha() for c in draft))
        if found:
            issues.append({"category": category, "reason": reason, "suggestion": suggestion})
    if "!!" in draft or "!!!" in draft:
        issues.append({"category": "Accessibility / Style", "reason": "Repeated exclamation marks can make text harder to read and feel overly promotional.", "suggestion": "Use one punctuation mark."})
    return issues

@app.route("/", methods=["GET"])
def index():
    with connect() as conn:
        reviews = conn.execute("SELECT * FROM reviews ORDER BY id DESC LIMIT 8").fetchall()
    return render_template("index.html", reviews=reviews)

@app.route("/review", methods=["POST"])
def review():
    draft = request.form.get("draft", "").strip()
    if not draft:
        return redirect(url_for("index"))
    issues = check_text(draft)
    import json
    with connect() as conn:
        cur = conn.execute(
            "INSERT INTO reviews (draft, status, issues, created_at) VALUES (?, ?, ?, ?)",
            (draft, "Needs review" if issues else "Ready for review", json.dumps(issues), datetime.now().strftime("%d %b %Y, %I:%M %p"))
        )
        review_id = cur.lastrowid
    return redirect(url_for("result", review_id=review_id))

@app.route("/result/<int:review_id>")
def result(review_id):
    import json
    with connect() as conn:
        item = conn.execute("SELECT * FROM reviews WHERE id = ?", (review_id,)).fetchone()
    if item is None:
        return redirect(url_for("index"))
    return render_template("result.html", item=item, issues=json.loads(item["issues"]))

@app.route("/status/<int:review_id>", methods=["POST"])
def status(review_id):
    new_status = request.form.get("status", "Needs review")
    allowed = {"Approved", "Needs Changes", "Rejected", "Ready for review", "Needs review"}
    if new_status not in allowed:
        new_status = "Needs review"
    with connect() as conn:
        conn.execute("UPDATE reviews SET status = ? WHERE id = ?", (new_status, review_id))
    return redirect(url_for("result", review_id=review_id))

@app.route("/guidelines")
def guidelines():
    return render_template("guidelines.html", rules=SAMPLE_RULES)

@app.route("/history")
def history():
    with connect() as conn:
        reviews = conn.execute("SELECT * FROM reviews ORDER BY id DESC").fetchall()
    return render_template("history.html", reviews=reviews)

init_db()

if __name__ == "__main__":
    app.run(debug=True)
